import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;


public class EmployeeFileHandlerUI extends JFrame {

    private JTextArea outputArea;

    // Employee class (Serializable)
    static class Employee implements Serializable {
        private static final long serialVersionUID = 1L;

        int id;
        String name;
        double salary;

        public Employee(int id, String name, double salary) {
            this.id = id;
            this.name = name;
            this.salary = salary;
        }

        @Override
        public String toString() {
            return "ID: " + id +
                    ", Name: " + name +
                    ", Salary: " + salary;
        }
    }

    public EmployeeFileHandlerUI() {
        setTitle("Employee File Handling & Serialization");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Buttons
        JButton loadButton = new JButton("Load from Text File");
        JButton serializeButton = new JButton("Serialize");
        JButton deserializeButton = new JButton("Deserialize & Display");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(loadButton);
        buttonPanel.add(serializeButton);
        buttonPanel.add(deserializeButton);

        // Output area
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        add(buttonPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Button Actions
        loadButton.addActionListener(e -> loadEmployees());
        serializeButton.addActionListener(e -> serializeEmployees());
        deserializeButton.addActionListener(e -> deserializeEmployees());
    }

    private List<Employee> employeeList = new ArrayList<>();

    // Load from text file
    private void loadEmployees() {
        employeeList.clear();
        outputArea.setText("");

        try (BufferedReader br = new BufferedReader(new FileReader("employees.txt"))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                int id = Integer.parseInt(data[0]);
                String name = data[1];
                double salary = Double.parseDouble(data[2]);

                employeeList.add(new Employee(id, name, salary));
            }

            outputArea.append("Employees loaded from text file successfully!\n");

        } catch (IOException ex) {
            outputArea.append("Error reading text file.\n");
        }
    }

    // Serialize
    private void serializeEmployees() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("employees.dat"))) {
            oos.writeObject(employeeList);
            outputArea.append("Employees serialized successfully!\n");
        } catch (IOException ex) {
            outputArea.append("Serialization failed.\n");
        }
    }

    // Deserialize
    private void deserializeEmployees() {
        outputArea.append("\n--- Employee List ---\n");

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("employees.dat"))) {
            List<Employee> list = (List<Employee>) ois.readObject();

            for (Employee emp : list) {
                outputArea.append(emp.toString() + "\n");
            }

        } catch (IOException | ClassNotFoundException ex) {
            outputArea.append("Deserialization failed.\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new EmployeeFileHandlerUI().setVisible(true);
        });
    }
}
